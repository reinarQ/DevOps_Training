
<footer>
<img src="https://github.com/0ctavia/cogip/blob/development/assets/images/slogan.png?raw=true" alt="slogan 'vive la cogip'">
</footer>
</body>
</html>
