<?php
require 'view/navbarview.php';
require 'view/headerview.php';
function show($list){
    var_dump($list);
}

require 'view/footerview.php';
?>
