<form class="form1" action="" method="POST">
    <label for="name">Nom</label>
    <input type="text" id="firstname" class="firstname" name="firstname">
    <label for="vat">TVA</label>
    <input type="text" id="vat" class="vat" name="vat">
        <select name="country">
        <option value="Belgique">Belgique<option>
        <option value="France">France<option>
    </select>
    <select name="companyType">
        <option value="1">Fourniseurs</option>
        <option value="2">Clients</option>
    </select>
    <button type="submit" name="envoi">Envoi</button>
</form>