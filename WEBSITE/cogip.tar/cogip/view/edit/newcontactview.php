<form class="form1" action="" method="POST">
    <label for="firstname">Nom</label>
    <input type="text" id="firstname" class="firstname" name="firstname">
    <label for="lastname">Prénoms</label>
    <input type="text" id="lastname" class="lastname" name="lastname">
    <label for="telephone">téléphone</label>
    <input type="text" class="telephone" name="telephone">
    <label for="mail">Email</label>
    <input type="mail" id="mail" class="mail" name="email"> 
    <select name="company">
        <option value="1">Telenet</option>
        <option value="2">Belgacom</option>
        <option value="3">ElectricPower</option>
        <option value="Ravigna">Ravigna</option>
        <option value="Jouets Jean-Michel">Jouets Jean-Michel</option>
        <option value="Telenet">Telenet</option>
    </select>
    <button type="submit" name="envoi">Envoi</button>
</form>