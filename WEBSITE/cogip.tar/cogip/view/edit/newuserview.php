<form class="form1" action="" method="POST">
    <label for="username">User</label>
    <input type="text" id="username" class="username" name="username">
    <label for="password">Password</label>
    <input type="password" id="password" class="password" name="password">
    <select name="type">
        <option value="winner">Winner</option>
        <option value="admin">Admin</option>
        <option value="regular">Regular</option>
    </select>
    <input type="submit" name="envoi" value="envoi">
</form>