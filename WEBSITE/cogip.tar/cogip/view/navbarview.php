<section class="nav-bar">
	<img class="nav-img" src= "assets/images/cogip2000small.jpeg" />
	<ul class="list">
		<li><a href="home">Home</a></li>
		<li><a href="compagnies">Compagnies</a></li>
		<li><a href="factures">Factures</a></li>
		<li><a href="contacts">Contacts</a></li>
		<li><a href="clients">Clients</a></li>
		<li><a href="fournisseurs">Fourniseurs</a></li>
		<!-- <li><a href="logout">Déconnexion</a></li> -->
	</ul>
</section>