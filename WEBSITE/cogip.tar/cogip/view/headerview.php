<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="description" content="cogip application for administration and invoice management">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="assets/images/faviconcogip.ico" rel="icon" type="image/x-icon" />

    <title><?php echo $title ?></title>
</head>
<body id="<?php echo $_SESSION['bodytag']?>">
    <header>
        <?php // if (/*rajouter un truc pour tester qu'on est sur adminview*/) : ?> 
            <!--barre de navigation doit etre include-->
        <?php // endif ?>
		
    </header>
